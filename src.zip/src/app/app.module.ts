import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SigninComponent } from './customer/signin/signin.component';
import { HomeComponent } from './home/home.component';
import { CustomerHomepageComponent } from './customer/homepage/homepage.component';
import { CustomerLoginComponent } from './customer/customerlogin/customer-login.component';
import { CustomerLoginService } from './customer/customerlogin/customer-login.service';
import { SigninService } from './customer/signin/signin.service';
import { UserorAdminLoginComponent } from './useroradminlogin/useroradminlogin.component';

import { HttpClientModule } from '@angular/common/http';
import { AdminLoginComponent } from './admin/adminlogin/adminlogin.component';
import { AdminLoginService } from './admin/adminlogin/adminlogin.service';
import { FormsModule } from '@angular/forms';
import { BookComponent } from './customer/book/book.component';
import { BookService } from './customer/book/book.service';
import { AddBookComponent } from './admin/addbook/addbook.component';
import { DeletebookComponent } from './admin/deletebook/deletebook.component';
import { AdminhomepageComponent } from './admin/adminhomepage/adminhomepage.component';
import { CustomerdetailsComponent } from './customer/customerdetails/customerdetails.component';
import { OrderComponent } from './customer/order/order.component';
import { CartComponent } from './customer/cart/cart.component';
import { CommonModule } from '@angular/common';
import { ProfileComponent } from './customer/profile/profile.component';
import { CustomerService } from './customer/customerdetails/customerdetails.service';
import { CartService } from './customer/cart/cart.service';
import { PaymentComponent } from './customer/payment/payment.component';
import { PaymentService } from './customer/payment/payment.service';
import { OrderService } from './customer/order/order.service';
import { MyorderComponent } from './customer/myorder/myorder.component';
import { MyorderService } from './customer/myorder/myorder.service';
import { InventoryComponent } from './admin/inventory/inventory.component';
import { InventoryService } from './admin/inventory/inventory.service';
import { OrderHistoryComponent } from './admin/order-history/order-history.component';
import { OrderHistoryService } from './admin/order-history/order-history.service';
import { UpdatePriceComponent } from './admin/update-price/update-price.component';






@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CustomerHomepageComponent,
    UserorAdminLoginComponent,
    CustomerLoginComponent,
    SigninComponent,
    AdminLoginComponent,
    BookComponent,
    AddBookComponent,
    DeletebookComponent,
    AdminhomepageComponent,
    CustomerdetailsComponent,
    OrderComponent,
    CartComponent,
    ProfileComponent,
    PaymentComponent,
    MyorderComponent,
    InventoryComponent,
    OrderHistoryComponent,
    UpdatePriceComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    CommonModule

  ],
  providers: [CustomerLoginService,SigninService,AdminLoginService,BookService,CustomerService,CartService,OrderService,MyorderService,InventoryService,OrderHistoryService],
  bootstrap: [AppComponent]
})
export class AppModule { }
