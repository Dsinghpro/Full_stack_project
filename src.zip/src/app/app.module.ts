import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SigninComponent } from './signin/signin.component';
import { HomeComponent } from './home/home.component';
import { HomepageComponent } from './homepage/homepage.component';
import { CustomerLoginComponent } from './CustomerLogin/customer-login.component';
import { CustomerLoginService } from './CustomerLogin/customer-login.service';
import { SigninService } from './signin/signin.service';
import { UserorAdminLoginComponent } from './useroradminlogin/useroradminlogin.component';

import { HttpClientModule } from '@angular/common/http';
import { AdminLoginComponent } from './adminlogin/adminlogin.component';
import { AdminLoginService } from './adminlogin/adminlogin.service';
import { FormsModule } from '@angular/forms';
import { BookComponent } from './book/book.component';



@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HomepageComponent,
    UserorAdminLoginComponent,
    CustomerLoginComponent,
    SigninComponent,
    AdminLoginComponent,
    BookComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,

  ],
  providers: [CustomerLoginService,SigninService,AdminLoginService],
  bootstrap: [AppComponent]
})
export class AppModule { }
