import { Component } from '@angular/core';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent {
  titleQuery: string = '';
  categoryQuery: string = '';

  searchBooks() {
    // Implement your book search logic here.
    // You can use the titleQuery and categoryQuery to filter books.
    // Update this.searchResults with the search results.
  }
}
