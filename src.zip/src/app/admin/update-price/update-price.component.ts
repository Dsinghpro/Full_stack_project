import { Component } from '@angular/core';
import { BookService } from '../../customer/book/book.service';

@Component({
  selector: 'app-update-price',
  templateUrl: './update-price.component.html',
  styleUrls: ['./update-price.component.css']
})
export class UpdatePriceComponent {

  bookId: any;
  price: any;

constructor(private bookService:BookService){}

updateBookPrice() {
   // Replace with the actual book ID.
  this.bookService.updatePrice(this.bookId, this.price).subscribe(
    (response) => {
      console.log('Price updated successfully', response);
      // Handle success, e.g., show a success message.
    },
    (error) => {
      console.error('Error updating price', error);
      // Handle error, e.g., show an error message.
    }
  );
}

}
