import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { tap } from 'rxjs/operators'; 
@Injectable()
export class AdminLoginService {
    constructor(private httpClient: HttpClient) {}
    value:boolean=false;
   public loginHere(login_name: string, password: string): Observable<any> {

        const url = "http://localhost:8088/admin/login";
        const data = {

            "loginName": login_name,

            "password": password

        };

 

        const options = {

            headers: new HttpHeaders({ 'Content-Type': 'application/json' }),

            responseType: 'text' as 'json'

          };

     

 

          return this.httpClient.post(url, data, options)

    }

 

   

}