import { Component } from '@angular/core';
import { OrderHistoryService } from './order-history.service';

@Component({
  selector: 'app-order-history',
  templateUrl: './order-history.component.html',
  styleUrls: ['./order-history.component.css']
})
export class OrderHistoryComponent {
  searchResults: any[] = [];
  
  constructor(private orderHistoryService:OrderHistoryService) {}

  ngOnInit() {
    this.getOrderHistory()
    
    
  }

  getOrderHistory() {
    this.orderHistoryService.getOrderHistory().subscribe((data) => {
        this.searchResults = data;
      });
  }
}
