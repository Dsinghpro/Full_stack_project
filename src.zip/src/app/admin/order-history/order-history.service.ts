import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})

export class OrderHistoryService{
    private baseUrl = 'http://localhost:8088/cartHistory/all'; 

  constructor(private http:HttpClient) {}

  getOrderHistory(): Observable<any[]> {
   
    return this.http.get<any[]>(`${this.baseUrl}`);
  }
}