import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AddBookService } from '../addbook/addbook.service';
import { BookService } from '../../customer/book/book.service';

@Component({
  selector: 'app-adminhomepage',
  templateUrl: './adminhomepage.component.html',
  styleUrls: ['./adminhomepage.component.css']
})
export class AdminhomepageComponent {
 
  myForm:any;
  bookId: any;
  price: any;

  constructor(private addbookservice:AddBookService,private router:Router,private bookService:BookService){}

 

    submitForm(myForm:any) {
      console.log(myForm);
      this.addbookservice.addBook(myForm).subscribe();
    }
    redirecttoaddbook()
    {
        this.router.navigate(["/addbook"]);
    }
    redirecttoremovebook()
    {
        this.router.navigate(["/deletebook"]);
    }
    
  redirecttoViewCustomers(){
      this.router.navigate(['/customerdetails'])
  }

  redirectToViewInventory(){
    this.router.navigate(['/inventory'])
  }
  redirectToViewOrderHistory(){
    this.router.navigate(['/orderHistory'])
  }
  redirectToUpdatePrice(){
    this.router.navigate(['/updatePrice'])
  }
  redirecttofirst()

  {
   
    window.localStorage.clear();
    this.router.navigate(['/'])

  }
}


  
