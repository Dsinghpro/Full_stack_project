import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class DeleteBookService {
    baseUrl = 'http://localhost:8088/book';

  constructor(private http: HttpClient) {}

  deleteBookById(bookId: number) {
    const url = `${this.baseUrl}/${bookId}`;
    return this.http.delete(url, { observe: 'response' });
    
  }
}
