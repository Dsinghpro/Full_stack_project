import { Component } from '@angular/core';
import { DeleteBookService } from './deletebook.service';
import { BookService } from '../../customer/book/book.service';

@Component({
  selector: 'app-deletebook',
  templateUrl: './deletebook.component.html',
  styleUrls: ['./deletebook.component.css']
})
export class DeletebookComponent {
  bookId: number=0;
  books:any[]=[];
  
  
  constructor(private deleteBookService: DeleteBookService) {}

  

  deleteBook(bookId: number) {
    if (!bookId) {
      console.error('No book selected to delete.');
      return;
    }
    this.deleteBookService.deleteBookById(bookId).subscribe(
      (response:any) => {
        console.log(response);
        // Check the response for success or error messages from the server
        if (response.status === 'book deleted succesfully') {

          alert('Book deleted successfully');

        } else if (response === 'book not found') {
          alert('Book not found.');
          // Handle the case where the book was not found.
        } else {
          alert('Unknown error');
          // Handle other possible error scenarios.
        }
      },
      (error) => {
        console.error('Error deleting book:', error);
        // Handle the error appropriately.
        // For example, you can display an error message to the user.
        
      }
    );
  }
  
}