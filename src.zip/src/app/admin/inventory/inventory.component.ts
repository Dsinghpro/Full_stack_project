import { Component } from '@angular/core';
import { InventoryService } from './inventory.service';

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent {

  searchResults: any[] = [];
  
  constructor(private inventoryService:InventoryService) {}

  ngOnInit() {
    this.getInventory()
    
    
  }

  getInventory() {
    this.inventoryService.getInventory().subscribe((data) => {
        this.searchResults = data;
      });
  }

}
