import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { AddBookService } from './addbook.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddBookComponent 
{





constructor(private addbookservice:AddBookService,router:Router){}

 

submitForm(myForm:any) {
  alert('Book is Added')
  console.log(myForm);
  this.addbookservice.addBook(myForm).subscribe();
}

 

}
