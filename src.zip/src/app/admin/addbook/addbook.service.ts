// book.service.ts
import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AddBookService {
   
constructor(private httpClient:HttpClient) {}



         addBook(formData:any):Observable<any>

          {

            const url = 'http://localhost:8088/book';

            const options = {

                headers: new HttpHeaders({ 'Content-Type': 'application/json' }),

                responseType: 'text' as 'json'
              };

            return this.httpClient.post(url, formData,options);

          }
}