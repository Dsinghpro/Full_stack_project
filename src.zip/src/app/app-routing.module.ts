/*import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LogInComponent } from './log-in/log-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { EmployeeListComponent2 } from './employee/employee-list.component2';
import { BookListComponent } from './book/book-list.component';
import { EmployeeListComponent } from './employee/employee-list.component';
import { TrainListComponent } from './train/trains-list.component';
import { ProductListComponent } from './product/product-list.component';
import{BookImageComponent} from './book/book-image.component';
import { LoginComponent } from './login.component';
import { SigninComponent } from './signin.component';
const routes: Routes = [
 {component:LoginComponent,path:'log-in'},
 {component:SigninComponent,path:'sign-in'},
 {component:EmployeeListComponent,path:'employeelist'},
 {component:BookListComponent,path:'booklist',children:[{component:BookImageComponent,path:'book-image/:bookName'}] } ,
 {component:TrainListComponent,path:'trainlist'},
 {component:ProductListComponent,path:'productlist'}
];
const routes:Routes=[
  {
    path:'',
    component:LogInComponent
  },
  {
    path:'signup',
    component:SignUpComponent

  },
  {
    path:'navbar',
    component:NavBarComponent
  }
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
*/
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SigninComponent } from './customer/signin/signin.component';
import { HomeComponent } from './home/home.component';
import { CustomerHomepageComponent } from './customer/homepage/homepage.component';
import { UserorAdminLoginComponent } from './useroradminlogin/useroradminlogin.component';
import { CustomerLoginComponent } from './customer/customerlogin/customer-login.component';
import { AdminLoginComponent } from './admin/adminlogin/adminlogin.component';
import { BookComponent } from './customer/book/book.component';
import { AddBookComponent } from './admin/addbook/addbook.component';
import { DeletebookComponent } from './admin/deletebook/deletebook.component';
import { AdminhomepageComponent } from './admin/adminhomepage/adminhomepage.component';
import { CustomerdetailsComponent } from './customer/customerdetails/customerdetails.component';
import { ProfileComponent } from './customer/profile/profile.component';
import { CartComponent } from './customer/cart/cart.component';
import { PaymentComponent } from './customer/payment/payment.component';
import { OrderComponent } from './customer/order/order.component';
import { MyorderComponent } from './customer/myorder/myorder.component';
import { InventoryComponent } from './admin/inventory/inventory.component';
import { OrderHistoryComponent } from './admin/order-history/order-history.component';
import { UpdatePriceComponent } from './admin/update-price/update-price.component';

// Import your login component here

const routes: Routes = [
  {path:'',component:HomeComponent },
  { path:'useroradminlogin',component:UserorAdminLoginComponent }, 
  {path:'sign-in',component: SigninComponent},
  {path:'customerhomepage',component:CustomerHomepageComponent},
  {path:'customerlogin',component:CustomerLoginComponent},
  {path:'adminlogin',component:AdminLoginComponent},
  {path:'search',component:BookComponent},
  {path:'addbook',component:AddBookComponent},
  {path:'deletebook',component:DeletebookComponent},
  {path:'adminhomepage',component:AdminhomepageComponent},
  {path:'customerdetails',component:CustomerdetailsComponent},
  {path:'profile',component:ProfileComponent},
  {path:'cart',component:CartComponent},
  {path:'payment',component:PaymentComponent},
  {path:'order',component:OrderComponent},
  {path:'myorders',component:MyorderComponent},
  {path:'inventory',component:InventoryComponent},
  {path:'orderHistory',component:OrderHistoryComponent},
  {path:'updatePrice',component:UpdatePriceComponent}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
