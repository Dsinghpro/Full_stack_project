/*import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LogInComponent } from './log-in/log-in.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { EmployeeListComponent2 } from './employee/employee-list.component2';
import { BookListComponent } from './book/book-list.component';
import { EmployeeListComponent } from './employee/employee-list.component';
import { TrainListComponent } from './train/trains-list.component';
import { ProductListComponent } from './product/product-list.component';
import{BookImageComponent} from './book/book-image.component';
import { LoginComponent } from './login.component';
import { SigninComponent } from './signin.component';
const routes: Routes = [
 {component:LoginComponent,path:'log-in'},
 {component:SigninComponent,path:'sign-in'},
 {component:EmployeeListComponent,path:'employeelist'},
 {component:BookListComponent,path:'booklist',children:[{component:BookImageComponent,path:'book-image/:bookName'}] } ,
 {component:TrainListComponent,path:'trainlist'},
 {component:ProductListComponent,path:'productlist'}
];
const routes:Routes=[
  {
    path:'',
    component:LogInComponent
  },
  {
    path:'signup',
    component:SignUpComponent

  },
  {
    path:'navbar',
    component:NavBarComponent
  }
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
*/
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SigninComponent } from './signin/signin.component';
import { HomeComponent } from './home/home.component';
import { HomepageComponent } from './homepage/homepage.component';
import { UserorAdminLoginComponent } from './useroradminlogin/useroradminlogin.component';
import { CustomerLoginComponent } from './CustomerLogin/customer-login.component';
import { AdminLoginComponent } from './adminlogin/adminlogin.component';
// Import your login component here

const routes: Routes = [
  {path:'',component:HomeComponent },
  { path:'useroradminlogin',component:UserorAdminLoginComponent }, 
  {path:'sign-in',component: SigninComponent},
  {path:'homepage',component:HomepageComponent},
  {path:'customerlogin',component:CustomerLoginComponent},
  {path:'adminlogin',component:AdminLoginComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
