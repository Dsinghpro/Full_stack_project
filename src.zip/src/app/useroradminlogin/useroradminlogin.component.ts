import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'useroradmin-login',
  templateUrl: './useroradminlogin.component.html',
  styleUrls: ['./useroradminlogin.component.css']
})
export class UserorAdminLoginComponent {
    constructor(private router: Router) {}

  adminLogin() {
    // Implement admin login logic here
    //console.log('Admin login clicked');
    this.router.navigate(['/adminlogin']);
  }

  customerLogin() {
    // Implement customer login logic here
    //console.log('Customer login clicked');
    this.router.navigate(['/customerlogin']);
  }
}
