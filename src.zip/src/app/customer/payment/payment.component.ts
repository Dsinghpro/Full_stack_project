import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent {

  cardNumber: string = '';
  expiryDate: string = '';
  cvv: string = '';

  constructor(private router:Router){}

  processPayment() {
    if (this.cardNumber.length !== 16) {
      // Card number must be exactly 14 digits
      alert('Invalid card number');
      return;
    }

    if (this.cvv.length !== 3) {
      // CVV must be 3 digits
      alert('Invalid CVV');
      return;
    }

    // Add your payment processing logic here
    // This could involve making an HTTP request to a payment gateway
    // or any other method you prefer for handling payments.
    // For testing purposes, you can display a success message.
    alert('Order Placed Successfully');
  }
  paymentDone(){
    alert("Succesful Payment! Order placed")
    this.router.navigate(['/customerhomepage'])
  }
  cashOnDelivery(){
    alert("Thank you for Shopping with us! Order placed")
    this.router.navigate(['/customerhomepage'])
  }

  

}
