import { Component } from '@angular/core';
import { CustomerLoginService } from './customer-login.service';
import { Router } from '@angular/router';


@Component({

 

  selector: 'app-customer-login',
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.css']

 

})

 

export class CustomerLoginComponent {

  constructor(private loginService: CustomerLoginService,private router:Router) {}

  redirectToHomePage(Mobile_No:string,Password:string)
    {
        this.loginService.loginHere(Mobile_No, Password).subscribe(

            (response) => {
              console.log(response);
             
              if(response  == 0){

                window.alert('Wrong input');

              }
             else{
              this.router.navigate(['/customerhomepage'])
              window.localStorage.setItem('id',response);
              }
             }           
           )
    }
    redirectToSignIn()
    {
        this.router.navigate(["/sign-in"])
    }
  }