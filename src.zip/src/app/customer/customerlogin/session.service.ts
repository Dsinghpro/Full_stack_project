
// session.service.ts

import { Injectable } from '@angular/core';

 

@Injectable({

  providedIn: 'root'

})

export class SessionService {

  private readonly CUSTOMER_ID_KEY = 'customer_id';

 

  constructor() {}

 

  setCustomerId(customerId: number) {

    sessionStorage.setItem(this.CUSTOMER_ID_KEY, customerId.toString());

  }

 

  getCustomerId(): number | null {

    const customerId = sessionStorage.getItem(this.CUSTOMER_ID_KEY);

    return customerId ? parseInt(customerId, 10) : null;

  }

}
