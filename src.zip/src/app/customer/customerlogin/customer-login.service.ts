import { Injectable } from "@angular/core";

import { Observable } from "rxjs";

import { HttpClient, HttpHeaders } from '@angular/common/http';

import { tap } from 'rxjs/operators';

 

 

@Injectable()

export class CustomerLoginService {

    constructor(private httpClient: HttpClient) {}

 

    value:boolean=false;

 

    public loginHere(mobileNo: string, password: string): Observable<any> {

        const url = "http://localhost:8088/customer/login";
        const data = {

            "mobileNo": mobileNo,
            "password": password
        };

 

        const options = {

            headers: new HttpHeaders({ 'Content-Type': 'application/json' }),
            responseType: 'text' as 'json', 
            withCredentials:true

          };


          return this.httpClient.post(url, data,options);

        

    }

 

   

}

 