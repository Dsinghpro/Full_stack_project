import { Component } from '@angular/core';
import { BookService } from '../book/book.service';
import { Router } from '@angular/router';
import { CartService } from '../cart/cart.service';
import { OrderService } from '../order/order.service';


@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class CustomerHomepageComponent {

  input:string='';
  searchResults: any[] = [];
  
 

  constructor(private bookservice:BookService, private router:Router,private cartService:CartService,private orderService:OrderService) {}

  ngOnInit(): void {
    this.getBooks();
  }

  search(){
    this.router.navigate(['/search'])
  }

  searchBooks(){
    
    if (this.input.trim() !== '') {
      this.bookservice.searchBooks(this.input).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }

  getBooks() {
    this.bookservice.getBooks().subscribe((data) => {
        this.searchResults = data;
      });
  }
  redirecttofirst()

  {
   
    window.localStorage.removeItem('id');

    this.router.navigate(['/'])


  }

  profile()
  {
    this.router.navigate(['/profile'])
  }

  cart(bookId:any){
    const data = {
      "bookID":bookId,
      "Custid":window.localStorage.getItem('id')
    }
    console.log(data);
    this.cartService.addToCart(data).subscribe();
    window.alert('added to cart');

  }

  
  goToCart() {
    this.router.navigateByUrl('/cart');
  }

  myOrders() {
    this.router.navigateByUrl('/myorders');
  }

}

  /*searchBooksByTitle() {
    if (this.title.trim() !== '') {
      this.bookservice.searchBooksByTitle(this.title).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }

  searchBooksByCategory(){
    if (this.category.trim() !== '') {
      this.bookservice.searchBooksByCategory(this.category).subscribe((data) => {
        this.searchResults = data;
      });
    }
  }

  getBooks() {
    this.bookservice.getBooks().subscribe((data) => {
        this.searchResults = data;
      });
  }
  redirecttofirst()

  {

    this.router.navigate(['/home'])

  }
}*/
