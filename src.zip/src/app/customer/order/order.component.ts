import { Component, OnInit } from '@angular/core';
import { OrderService } from './order.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  lastOrders: any[] = [];

  constructor(private orderService:OrderService,private router:Router) {
  }

  ngOnInit(): void {
    this.getlastorder();
    
  }

  getlastorder() {
    
    this.orderService.getlastorder().subscribe(
      (response) => {
        this.lastOrders = response;
        console.log(JSON.stringify(response));
        
      },
      (error) => {
        console.error('Failed to fetch last orders:', error);
      }
    );
  }

  payment(){
    this.router.navigate(['/payment'])
  }
}
