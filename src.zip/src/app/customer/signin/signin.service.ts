import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';
import { Observable } from "rxjs";

@Injectable({
    providedIn: 'root'
})
export class SigninService {
    Url = "http://localhost:8088/customer/Signup"; 

    constructor(private httpClient: HttpClient) {}

    signInHere(userData: any): Observable<any> {
        
        return this.httpClient.post(this.Url, userData);
    }
}
