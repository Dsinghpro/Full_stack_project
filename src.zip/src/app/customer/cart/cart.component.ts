import { Component, OnInit } from '@angular/core';
import { CartService } from './cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {

  // customerRegistrationId: any;

  constructor(private cartService: CartService,private route:Router) {}

  ansButton = true;

  cartData:any;
  ngOnInit() {
    this.getCartData();
  }

  getCartData() {
    const id = window.localStorage.getItem('id');
    this.cartService.getAllItemsOfCart(id).subscribe((res)=>{
      console.log(res);
      this.cartData = res;

      if (JSON.stringify(res).length<=2) {
        alert('Empty Cart');
        this.ansButton = false;
      }
    });
  }

  decreaseQuantity(cartId: number) {
    window.location.reload();
    this.cartService.decreaseQuantity(cartId).subscribe(
      (response) => {
          
      },
      (error) => {
        console.error('Error decreasing quantity:', error);
      }
    );
  }

  increaseQuantity(cartId: number) {
    window.location.reload();
    this.cartService.increaseQuantity(cartId).subscribe(
      (response) => {
       
      },
      (error) => {
        console.error('Error increasing quantity:', error);
      }
    );
  }

  placeOrder() {
    const id = window.localStorage.getItem('id');
    this.cartService.placeOrder(id).subscribe(
      (response) => {
        this.cartData();
      },
      (error) => {
        // Handle errors, e.g., show an error message
        console.error('Failed to place the order:', error);
      }
    );
    this.route.navigateByUrl('/order');

  }

}





