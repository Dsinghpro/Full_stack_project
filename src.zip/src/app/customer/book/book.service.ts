// book.service.ts
import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class BookService {
 
  private baseUrl1 = 'http://localhost:8088/book/title'; 

  private baseUrl2='http://localhost:8088/book/category';

  private Url='http://localhost:8088/book/searchBook';

  private baseUrl='http://localhost:8088/book/all';

  constructor(private http:HttpClient) {}
 
  searchBooks(input: string): Observable<any> {
    console.log(input);
    return this.http.get<any[]>(`${this.Url}/${input}`);
  
  }

  searchBooksByTitle(title: string): Observable<any> {
    console.log(title);
    return this.http.get<any[]>(`${this.baseUrl1}/${title}`);
  
  }

  searchBooksByCategory(category: string) {
    console.log(category);
    return this.http.get<any[]>(`${this.baseUrl2}/${category}`);
  }

  getBooks(): Observable<any[]> {
   
    return this.http.get<any[]>(`${this.baseUrl}`);
  }

  
  updatePrice(bookId: number, price: number) {

    const url = `http://localhost:8088/book/updatePrice/${bookId}`;

    const options = {

        headers: new HttpHeaders({ 'Content-Type': 'application/json' }),

        responseType: 'text' as 'json'
      };

    return this.http.post(url, price,options);

  }
}
