import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})

export class MyorderService{
    constructor(private http:HttpClient) {}

    getlastorder(): Observable<any> {
        const url = 'http://localhost:8088/order/last';
         return this.http.get(url);
         
        }
        
        Myorders(id:any): Observable<any> {
            const url = `http://localhost:8088/cartHistory/${id}`;
            return this.http.get(url);
          }
          
}