import { Component } from '@angular/core';
import { MyorderService } from './myorder.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-myorder',
  templateUrl: './myorder.component.html',
  styleUrls: ['./myorder.component.css']
})


export class MyorderComponent {
  searchResults:any[]=[];
  input: any;
  constructor(private myorderService:MyorderService,private router:Router){}

  ngOnInit(): void {
    this.myorder();
  }

  myorder() {
    const id = window.localStorage.getItem('id');
    
    this.myorderService.Myorders(id).subscribe(
      (data) => {
        this.searchResults = data;
      },
    );
  }

  redirecttohomepage()

  {
   
    this.router.navigate(['/customerhomepage'])


  }
  
}


