import { Component } from '@angular/core';
import { AdminLoginService } from './adminlogin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminLoginComponent 
{
    //isLoggedIn:boolean=false;
    constructor(private adminloginService:AdminLoginService,private router:Router){}
    redirectToHomePage(login_name:string,password:string)
    {
        this.adminloginService.loginHere(login_name, password).subscribe(
            (response) => {
              console.log(response)
              if(response==1){
                this.router.navigate(['/homepage'])
              }
              else{
                alert("NOT VALID")
              }
             },
       
             (error) =>
       
             {
       
               console.log("login n")
       
             }
       
           )
           
           
       

    }
    redirectToSignIn()
    {
        this.router.navigate(['/sign-in']);
    }

  }
   
