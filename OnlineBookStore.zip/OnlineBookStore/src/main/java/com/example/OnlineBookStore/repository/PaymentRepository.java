package com.example.OnlineBookStore.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.example.OnlineBookStore.entity.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Integer> {

    // This method finds the last payment by selecting the payment with the maximum order_id using a native SQL query
    @Query(value = "SELECT * FROM payment WHERE order_id = (SELECT MAX(order_id) FROM payment)", nativeQuery = true)
    Payment findLastPayment();

}
