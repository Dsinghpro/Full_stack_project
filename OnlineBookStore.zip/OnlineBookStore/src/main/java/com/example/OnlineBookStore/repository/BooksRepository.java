package com.example.OnlineBookStore.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.example.OnlineBookStore.entity.Books;

public interface BooksRepository extends JpaRepository<Books, Integer> {

    // Find books by author ID using a native SQL query
    @Query(value = "SELECT * FROM Books WHERE author_id = :authorId", nativeQuery = true)
    Optional<Books> findBooksByAuthorId(@Param("authorId") int authorId);

    // Search for books by a keyword in the category or title
    @Query(nativeQuery = true, value = "select * from books where category like %:input% or title like %:input%")
    public List<Books> searchBooks(@Param("input") String input);

    // Update the price of a book by its book ID using a native SQL query
    @Transactional
    @Modifying
    @Query(nativeQuery = true, value = "update books set price = :price where book_id = :book_id")
    void updatePrice(@Param("book_id") int book_id, @Param("price") float price);

	
    
 

}
