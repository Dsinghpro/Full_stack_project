package com.example.OnlineBookStore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.OnlineBookStore.entity.Payment;
import com.example.OnlineBookStore.repository.PaymentRepository;

@CrossOrigin(origins = {"http://localhost:4200"}, allowCredentials = "true")
@RestController
@RequestMapping("/payment")
public class PaymentController {

    private final PaymentRepository paymentRepository;

    @Autowired
    public PaymentController(PaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    // This endpoint retrieves all payments
    @GetMapping("/all")
    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    // This endpoint retrieves the last payment made
    @GetMapping("/lastPayment")
    public ResponseEntity<Payment> getLastPayment() {
        Payment lastPayment = paymentRepository.findLastPayment();

        if (lastPayment != null) {
            return ResponseEntity.ok(lastPayment);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
