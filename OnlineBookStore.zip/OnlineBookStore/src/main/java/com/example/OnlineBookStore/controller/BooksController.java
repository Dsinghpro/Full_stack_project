package com.example.OnlineBookStore.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.OnlineBookStore.entity.Authors;
import com.example.OnlineBookStore.entity.Books;
import com.example.OnlineBookStore.entity.Publication;
import com.example.OnlineBookStore.repository.AuthorsRepository;
import com.example.OnlineBookStore.repository.BooksRepository;
import com.example.OnlineBookStore.repository.CustomerRegistrationRepository;
import com.example.OnlineBookStore.repository.PublicationRepository;

@CrossOrigin
@RestController
@RequestMapping("/book")
public class BooksController {

    @Autowired
    AuthorsRepository authorsRepository;

    @Autowired
    PublicationRepository publicationRepository;
    
    @Autowired
    CustomerRegistrationRepository customerRegistrationRepository;

    private final BooksRepository bookRepository;

    @Autowired
    public BooksController(BooksRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // This endpoint retrieves all books
    @GetMapping("/all")
    public List<Books> getAllBooks() {
        return bookRepository.findAll();
    }

    // This endpoint searches for books based on a keyword in the category or title
    @GetMapping(value = "/searchBook/{input}")
    public ResponseEntity<List<Books>> searchBooks(@PathVariable String input) {
        List<Books> books = bookRepository.searchBooks(input);
        if (!books.isEmpty()) {
            return new ResponseEntity<List<Books>>(books, HttpStatus.OK);
        } else {
            return new ResponseEntity<List<Books>>(HttpStatus.NOT_FOUND);
        }
    }

    // This endpoint retrieves a book by its author_id
    @GetMapping("/{author_id}")
    public ResponseEntity<Books> getBookByAuthorId(@PathVariable int author_id) {
        Optional<Books> optionalBook = bookRepository.findBooksByAuthorId(author_id);
        if (optionalBook.isPresent()) {
            Books book = optionalBook.get();
            return ResponseEntity.ok(book);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // This endpoint allows creating a new book
    @PostMapping(consumes = "application/json")
    public void createBook(@RequestBody Map<String, String> map) {
        try {
            Integer publisherId = Integer.parseInt(map.get("publisherId"));
            Integer authorId = Integer.parseInt(map.get("authorId"));
            Authors authors = authorsRepository.getById(authorId);
            Publication publication = publicationRepository.getById(publisherId);
            String title = map.get("title");
            String isbn = map.get("isbn");
            String category = map.get("category");
            Integer publicationYear = Integer.parseInt(map.get("publicationYear"));
            Float price = Float.parseFloat(map.get("price"));
            Integer quantity = Integer.parseInt(map.get("quantity"));
            String image = map.get("image");

            Books books = new Books();
            books.setAuthor(authors);
            books.setCategory(category);
            books.setTitle(title);
            books.setQuantity(quantity);
            books.setPublicationYear(publicationYear);
            books.setPublication(publication);
            books.setISBN(isbn);
            books.setPrice(price);
            books.setImage(image);

            System.out.println(books.toString());

            bookRepository.save(books);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // This endpoint allows deleting a book by its book_id
    @DeleteMapping("/{book_id}")
    public ResponseEntity<String> deleteBookById(@PathVariable int book_id) {
    	Optional<Books> bp = bookRepository.findById(book_id);
        if (bp.isPresent()) {
        	bookRepository.deleteById(book_id);
        	return new ResponseEntity<String>("book deleted succesfully",HttpStatus.OK);
        }
        return new ResponseEntity<String>("book not found",HttpStatus.NOT_FOUND);
    }

    // This endpoint allows updating the price of a book by its book_id
    @PostMapping("/updatePrice/{book_id}")
    public ResponseEntity<String> updatePrice(@PathVariable int book_id, @RequestBody float price) {
        Optional<Books> bp = bookRepository.findById(book_id);
        if (bp.isPresent()) {
            bookRepository.updatePrice(book_id, price);
            return new ResponseEntity<String>(HttpStatus.OK);
        }
        return new ResponseEntity<String>(HttpStatus.NOT_MODIFIED);
    }
}
