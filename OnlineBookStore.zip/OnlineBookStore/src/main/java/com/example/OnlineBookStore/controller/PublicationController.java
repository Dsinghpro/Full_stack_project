package com.example.OnlineBookStore.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.OnlineBookStore.entity.Publication;
import com.example.OnlineBookStore.repository.PublicationRepository;

@RestController
@RequestMapping("/publication")
public class PublicationController {

    private PublicationRepository publicationRepository;

    @Autowired
    public PublicationController(PublicationRepository publicationRepository) {
        this.publicationRepository = publicationRepository;
    }

    // This endpoint retrieves all publications
    @GetMapping("/all")
    public List<Publication> getAllPublications() {
        return publicationRepository.findAll();
    }

    // This endpoint retrieves a publication by its ID
    @GetMapping("/{publication_id}")
    public Optional<Publication> getPublicationById(@PathVariable int publication_id) {
        return publicationRepository.findById(publication_id);
    }

    // This endpoint inserts a new publication
    @PostMapping("/insert")
    public Publication insertPublication(@RequestBody Publication publication) {
        return publicationRepository.save(publication);
    }

    // This endpoint deletes a publication by its ID
    @DeleteMapping("/{publication_id}")
    public void deletePublication(@PathVariable int publication_id) {
        publicationRepository.deleteById(publication_id);
    }
}
