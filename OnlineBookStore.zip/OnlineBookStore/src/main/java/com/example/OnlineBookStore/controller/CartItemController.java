package com.example.OnlineBookStore.controller;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.OnlineBookStore.entity.CartItem;
import com.example.OnlineBookStore.repository.*;

@CrossOrigin(origins = {"http://localhost:4200"}, allowCredentials = "true")
@RestController
@RequestMapping("/cart")
public class CartItemController {

    private final CartItemRepository cartitemRepository;

    @Autowired
    BooksRepository booksRepository;

    @Autowired
    CustomerRegistrationRepository customerRegistrationRepository;

    @Autowired
    InventoryRepository inventoryRepository;

    @Autowired
    public CartItemController(CartItemRepository cartItemRepository) {
        this.cartitemRepository = cartItemRepository;
    }

    // This endpoint retrieves all cart items for a specific user based on their ID
    @GetMapping("/all/{id}")
    public List<CartItem> getAllCartItems(@PathVariable Integer id) {
        return cartitemRepository.getAllItemsFromCartByUserId(id);
    }

    // This endpoint allows inserting an item into the cart
    @PostMapping("/insertcart")
    public ResponseEntity<String> insertIntoCart(@RequestBody Map<String, String> map) {

        // Check if the item is already in the cart
        CartItem cartItem = cartitemRepository.findCartItemBycustomerRegistration(
            customerRegistrationRepository.findById(Integer.parseInt(map.get("Custid"))).get().getCustomerRegistrationId(),
            booksRepository.findById(Integer.parseInt(map.get("bookID"))).get().getBookId()
        );

        if (Objects.isNull(cartItem)) {
            Integer quantity = inventoryRepository.findQuantityByBookId(Integer.parseInt(map.get("bookID")));
            if (quantity > 0) {
                CartItem ci = new CartItem();
                ci.setBook(booksRepository.findById(Integer.parseInt(map.get("bookID"))).get());
                ci.setCustomerRegistration(customerRegistrationRepository.findById(Integer.parseInt(map.get("Custid"))).get());
                ci.setQuantity(1);
                cartitemRepository.save(ci);
                return new ResponseEntity<String>("Item Added", HttpStatus.OK);
            }
            return new ResponseEntity<String>("Insufficient quantity! Cannot add to cart", HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity<String>("Something Went Wrong", HttpStatus.BAD_REQUEST);
    }

    // This endpoint allows increasing the quantity of an item in the cart
    @PostMapping("/increase/{cartId}")
    public ResponseEntity<String> increaseQuantityInCart(@PathVariable Integer cartId) {
        CartItem cartItem = cartitemRepository.findById(cartId).get();
        if (Objects.isNull(cartItem) == false) {
            if (Objects.isNull(cartItem) == false) {
                Integer quantity = inventoryRepository.findQuantityByBookId(cartItem.getBook().getBookId());
                if (quantity > 0) {
                    cartItem.setQuantity(cartItem.getQuantity() + 1);
                    cartitemRepository.save(cartItem);
                    return new ResponseEntity<String>("Item Modified", HttpStatus.OK);
                }
            }
        }
        return new ResponseEntity<String>("Something Went Wrong; Please try after some time.", HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // This endpoint allows deleting an item from the cart by its cartId
    @DeleteMapping("/{cartId}")
    public ResponseEntity<String> deleteFromCart(@PathVariable Integer cartId) {
        CartItem cartItem = cartitemRepository.findById(cartId).get();
        if (Objects.isNull(cartItem) == false) {
            cartitemRepository.delete(cartItem);
            return new ResponseEntity<String>("Item Deleted", HttpStatus.OK);
        }
        return new ResponseEntity<String>("Something Went Wrong; Please try after some time.", HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // This endpoint allows decreasing the quantity of an item in the cart
    @PostMapping("/decrease/{cartId}")
    public ResponseEntity<String> decreaseQuantityInCart(@PathVariable Integer cartId) {
        CartItem cartItem = cartitemRepository.findById(cartId).get();
        if (Objects.isNull(cartItem) == false) {
            cartItem.setQuantity(cartItem.getQuantity() - 1);
            cartitemRepository.save(cartItem);
            if (cartItem.getQuantity() == 0)
                cartitemRepository.delete(cartItem);
            return new ResponseEntity<String>("Item Modified", HttpStatus.OK);
        }
        return new ResponseEntity<String>("Something Went Wrong; Please try after some time.", HttpStatus.INTERNAL_SERVER_ERROR);
    }

    // This endpoint allows deleting all items from the cart for a specific customerRegistrationId
    @DeleteMapping("/deleteAll")
    public void deleteCartItems(@RequestBody Integer customerRegistrationId) {
        cartitemRepository.deleteByCustomerRegistrationId(customerRegistrationId);
    }
}
