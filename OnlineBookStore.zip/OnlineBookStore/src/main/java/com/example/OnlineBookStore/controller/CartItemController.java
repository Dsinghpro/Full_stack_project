package com.example.OnlineBookStore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.OnlineBookStore.entity.CartItem;
import com.example.OnlineBookStore.repository.CartItemRepository;

@RestController
@RequestMapping("/cart")
public class CartItemController {
	
	private final CartItemRepository cartitemRepository;
	
	@Autowired
	public CartItemController(CartItemRepository cartItemRepository) {
		this.cartitemRepository=cartItemRepository;
	}
	
	@GetMapping("/all")
	public List<CartItem> getAllcartitem(){
		return cartitemRepository.findAll();
	}

}
