package com.example.OnlineBookStore.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;
import com.example.OnlineBookStore.entity.Order;

public interface OrderRepository extends JpaRepository<Order, Integer> {

    // This method is used to call a stored procedure named "PlaceOrder"
    @Procedure(name = "PlaceOrder")
    void placeOrder(@Param("customer_registration_id") int customerId);

    // This method finds orders by customer registration ID using a native SQL query
    @Query(nativeQuery = true, value = "SELECT * FROM Orders WHERE customer_registration_id = :customerRegistrationId")
    List<Order> findByCustomerRegistrationId(@Param("customerRegistrationId") int customerRegistrationId);

    // This method finds the last order by ordering the results by orderId in descending order and limiting to 1 result
    @Query("SELECT o FROM Order o ORDER BY o.orderId DESC LIMIT 1")
    List<Order> findLastOrders();

}
