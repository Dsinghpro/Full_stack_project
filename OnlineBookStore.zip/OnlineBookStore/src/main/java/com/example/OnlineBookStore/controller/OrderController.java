package com.example.OnlineBookStore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.OnlineBookStore.entity.CartItem;
import com.example.OnlineBookStore.entity.Order;
import com.example.OnlineBookStore.repository.*;
import jakarta.transaction.Transactional;

@CrossOrigin(origins = {"http://localhost:4200"}, allowCredentials = "true")
@RestController
@RequestMapping("/order")
public class OrderController {

    private OrderRepository orderRepository;

    @Autowired
    CartItemRepository cartItemRepository;

    @Autowired
    InventoryRepository inventoryRepository;

    @Autowired
    public OrderController(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    // This endpoint retrieves all orders
    @GetMapping("/all")
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    // This endpoint retrieves orders by customer ID
    @GetMapping("/{customer_registration_id}")
    public ResponseEntity<List<Order>> getOrdersByCustomerId(@PathVariable int customer_registration_id) {
        List<Order> orders = orderRepository.findByCustomerRegistrationId(customer_registration_id);
        if (!orders.isEmpty()) {
            return ResponseEntity.ok(orders);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // This endpoint retrieves the last placed orders
    @GetMapping("/last")
    public ResponseEntity<List<Order>> getLastOrders() {
        List<Order> lastOrders = orderRepository.findLastOrders();
        return ResponseEntity.ok(lastOrders);
    }

    // This endpoint allows placing an order
    @Transactional
    @PostMapping(value = "/placeOrder", consumes = "application/json", produces = "application/json")
    public ResponseEntity<String> placeOrder(@RequestBody int customerRegistrationId) {
        try {
            List<CartItem> cart = cartItemRepository.getAllItemsFromCartByUserId(customerRegistrationId);
            for (CartItem cartItem : cart) {
                // Retrieve the necessary information from the cart item
                Integer customerId = cartItem.getCustomerRegistration().getCustomerRegistrationId();
                // Call the placeOrder stored procedure from the repository
                Integer quantity = inventoryRepository.findQuantityByBookId(cartItem.getBook().getBookId());
                if (quantity > 0) {
                    orderRepository.placeOrder(customerId);
                    // Clear the cart after placing the order
                    cartItemRepository.deleteByCustomerRegistrationId(customerId);
                    break;
                } else {
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                            .body("Failed to place one or more orders due to insufficient quantity");
                }
            }
            return ResponseEntity.ok("Orders placed successfully.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to place one or more orders: " + e.getMessage());
        }
    }
}
