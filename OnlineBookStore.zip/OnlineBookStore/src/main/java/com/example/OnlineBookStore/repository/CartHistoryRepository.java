package com.example.OnlineBookStore.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.example.OnlineBookStore.entity.CartHistory;

public interface CartHistoryRepository extends JpaRepository<CartHistory, Integer> {

    // This method retrieves a list of cart history records by customer registration ID
    @Query(nativeQuery = true, value = "SELECT * FROM cart_history WHERE customer_registration_id = :customerRegistrationId")
    List<CartHistory> findByCustomerRegistrationId(@Param("customerRegistrationId") int customerRegistrationId);
}
