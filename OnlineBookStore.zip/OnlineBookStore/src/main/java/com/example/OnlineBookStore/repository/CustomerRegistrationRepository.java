package com.example.OnlineBookStore.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.example.OnlineBookStore.entity.CustomerRegistration;

public interface CustomerRegistrationRepository extends JpaRepository<CustomerRegistration,Integer>{

		@Procedure(procedureName="insertCustomerdetails")
		void insertCustomer(
				@Param("p_first_name") String firstName,
				@Param("p_last_name")  String lastName,
				@Param("p_email") String email,
				@Param("p_address") String address,
				@Param("p_user_id") String userId,
				@Param("p_mobileNo") String mobileNo,
				@Param("p_password ") String password
				);
		@Query(nativeQuery=true,value="select * from Customer_Registration where mobile_No =:mobileNumber AND password =:password")
			CustomerRegistration CustomerLogin(String mobileNumber,String password);
}
