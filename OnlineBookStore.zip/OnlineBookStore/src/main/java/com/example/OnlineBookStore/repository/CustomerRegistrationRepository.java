package com.example.OnlineBookStore.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.query.Param;

import com.example.OnlineBookStore.entity.CustomerRegistration;

public interface CustomerRegistrationRepository extends JpaRepository<CustomerRegistration, Integer> {

    // This method is used to call a stored procedure named "insertCustomerdetails"
    @Procedure(procedureName = "insertCustomerdetails")
    void insertCustomer(
        @Param("p_first_name") String firstName,
        @Param("p_last_name") String lastName,
        @Param("p_email") String email,
        @Param("p_address") String address,
        @Param("p_user_id") String userId,
        @Param("p_mobileNo") String mobileNo,
        @Param("p_password ") String password
    );

    // This method finds a customer registration by mobile number and password using a native SQL query
    @Query(nativeQuery = true, value = "select * from Customer_Registration where mobile_No = :mobileNo AND password = :password")
    CustomerRegistration findByMobileNoAndPassword(@Param("mobileNo") String mobileNo, @Param("password") String password);

    // This method finds all customer registrations by customer registration ID
    List<CustomerRegistration> findAllBycustomerRegistrationId(int customerRegistrationId);

}
