package com.example.OnlineBookStore.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.example.OnlineBookStore.entity.Inventory;

public interface InventoryRepository extends JpaRepository<Inventory, Integer> {

    // This method retrieves the stock level available for a book by its book ID using a native SQL query
    @Query(value = "select stock_level_avilable from inventory where book_id = :book", nativeQuery = true)
    int findQuantityByBookId(@Param("book") int book);

}
