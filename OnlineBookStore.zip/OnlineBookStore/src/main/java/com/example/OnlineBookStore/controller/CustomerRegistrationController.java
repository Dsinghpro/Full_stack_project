package com.example.OnlineBookStore.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.OnlineBookStore.entity.CustomerRegistration;
import com.example.OnlineBookStore.repository.CustomerRegistrationRepository;

import jakarta.servlet.http.HttpSession;

@CrossOrigin(origins = {"http://localhost:4200"}, allowCredentials = "true")
@RestController
@RequestMapping("/customer")
public class CustomerRegistrationController {

    private final CustomerRegistrationRepository customerregistrationRepository;

    @Autowired
    public CustomerRegistrationController(CustomerRegistrationRepository customerregistrationRepository) {
        this.customerregistrationRepository = customerregistrationRepository;
    }

    // This endpoint retrieves all customer registrations
    @GetMapping("/all")
    public List<CustomerRegistration> getAllCustomers() {
        return customerregistrationRepository.findAll();
    }

    // This endpoint allows customer registration
    @PostMapping("/Signup")
    public CustomerRegistration insertCustomer(@RequestBody CustomerRegistration customerRegistration) {
        return customerregistrationRepository.save(customerRegistration);
    }

    // This endpoint retrieves customer information by customerRegistrationId
    @GetMapping("/getUser/{customerRegistrationId}")
    public ResponseEntity<List<CustomerRegistration>> getCustomer(@PathVariable int customerRegistrationId) {
        List<CustomerRegistration> customers = customerregistrationRepository.findAllBycustomerRegistrationId(customerRegistrationId);
        return ResponseEntity.ok(customers);
    }

    // This endpoint allows customer login
    @PostMapping(value = "/login", consumes = "application/json")
    public ResponseEntity<Integer> customerLogin(HttpSession req, @RequestBody CustomerRegistration customerRegistration) {
        String mobileNo = customerRegistration.getMobileNo();
        String password = customerRegistration.getPassword();
        CustomerRegistration c =  customerregistrationRepository.findByMobileNoAndPassword(mobileNo, password);
        if (c != null) {
            req.setAttribute("customerId", c.getCustomerRegistrationId());
            return new ResponseEntity<Integer>(c.getCustomerRegistrationId(), HttpStatus.OK);
        } else {
            return new ResponseEntity<Integer>(0, HttpStatus.BAD_REQUEST);
        }
    }
}
