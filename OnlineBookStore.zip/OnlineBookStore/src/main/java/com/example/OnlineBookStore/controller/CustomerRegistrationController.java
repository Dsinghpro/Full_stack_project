package com.example.OnlineBookStore.controller;


import java.util.Map;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.OnlineBookStore.entity.CustomerRegistration;
import com.example.OnlineBookStore.repository.CustomerRegistrationRepository;


@CrossOrigin
@RestController
@RequestMapping("/customer")
public class CustomerRegistrationController<mobile_No> {
	
	private final CustomerRegistrationRepository customerregistrationRepository;
	
	@Autowired
	public CustomerRegistrationController(CustomerRegistrationRepository customerregistrationRepository ) {
		this.customerregistrationRepository=customerregistrationRepository;
	}
	
	
	
	@PostMapping("/Signup")
	public CustomerRegistration insertCustomer(@RequestBody CustomerRegistration customerRegistration) {
		return customerregistrationRepository.save(customerRegistration);
	}
	
//	@PostMapping("/login/{mobile_No}/{password}")
//    public boolean customerLogin(
//            @PathVariable("mobile_No") String mobileNo,
//            @PathVariable("password") String password
//    ) {
//		System.out.println("Check Pount ->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
//        return customerregistrationRepository.CustomerLogin(mobileNo, password);
//    }
	
	@PostMapping("/login")
	public int customerLogin(@RequestBody Map<String, String>map) {
		try {
			String mobileNo = map.get("mobileNo");
			String password = map.get("password");
			
			CustomerRegistration customerRegistration =  customerregistrationRepository.CustomerLogin(mobileNo, password);
			
			
			if (Objects.isNull(customerRegistration)) {
				return 0;
			} else {
				return 1;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	

}
