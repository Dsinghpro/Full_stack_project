package com.example.OnlineBookStore.entity;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "cart_history")
public class CartHistory{

    @Id
    @Column(name = "cart_id")
    private int cartId;

    @ManyToOne
    @JoinColumn(name = "book_id")
    private Books book;


    @Column(name = "quantity")
    private int quantity;
    
    @ManyToOne
    @JoinColumn(name = "customer_registration_id")
    private CustomerRegistration customerRegistration;
    
    
    @Column(name = "order_placed_at")
    private Date order_placed_at;

    public CartHistory() {
        
    }

   

    public int getCartId() {
        return cartId;
    }

    public void setCartId(int cartId) {
        this.cartId = cartId;
    }

    public Books getBook() {
        return book;
    }

    public void setBook(Books book) {
        this.book = book;
    }
    
    
    public CustomerRegistration getCustomerRegistration() {
        return customerRegistration;
    }

    public void setCustomerRegistration(CustomerRegistration customerRegistration) {
        this.customerRegistration = customerRegistration;
    }
    


    public Date getOrder_placed_at() {
		return order_placed_at;
	}



	public void setOrder_placed_at(Date order_placed_at) {
		this.order_placed_at = order_placed_at;
	}



	public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}

