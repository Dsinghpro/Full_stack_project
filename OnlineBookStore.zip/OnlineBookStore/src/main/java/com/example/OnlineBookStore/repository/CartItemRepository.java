package com.example.OnlineBookStore.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.OnlineBookStore.entity.CartItem;

import jakarta.transaction.Transactional;

public interface CartItemRepository extends JpaRepository<CartItem, Integer> {

    // Find a cart item by customer registration ID and book ID
    @Query(nativeQuery = true, value = "select * from cart where customer_registration_id = :customerRegistration and book_id = :book")
    CartItem findCartItemBycustomerRegistration(@Param("customerRegistration") int customerRegistration, @Param("book") int book);

    // Get all items from the cart by user ID
    @Query(nativeQuery = true, value = "select * from cart where customer_registration_id = :userId")
    List<CartItem> getAllItemsFromCartByUserId(@Param("userId") int userId);

    // Delete all cart items by customer registration ID
    @Modifying
    @Transactional
    @Query(nativeQuery = true, value = "delete from cart where customer_registration_id = :customerRegistrationId")
    void deleteByCustomerRegistrationId(@Param("customerRegistrationId") int customerRegistrationId);
}
