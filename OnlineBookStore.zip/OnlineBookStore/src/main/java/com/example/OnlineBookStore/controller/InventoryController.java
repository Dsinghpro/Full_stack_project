package com.example.OnlineBookStore.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.OnlineBookStore.entity.Inventory;
import com.example.OnlineBookStore.repository.InventoryRepository;

@RestController
@RequestMapping("/inventory")
public class InventoryController {
    
    private final InventoryRepository inventoryRepository;
    
    @Autowired
    public InventoryController(InventoryRepository inventoryRepository) {
        this.inventoryRepository = inventoryRepository;
    }
    
    // This endpoint retrieves all inventory items
    @GetMapping("/all")
    public List<Inventory> getAllInventory() {
        return inventoryRepository.findAll();
    }
}
