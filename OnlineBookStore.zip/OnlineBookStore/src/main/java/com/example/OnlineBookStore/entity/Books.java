package com.example.OnlineBookStore.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;


@Entity
public class Books {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "book_id")
    private int bookId;

    @ManyToOne
    @JoinColumn(name = "author_id")
    private Authors author;

    @ManyToOne
    @JoinColumn(name = "publication_id")
    private Publication publication;

    @Column(name = "Title")
    private String title;

    @Column(name = "ISBN")
    private String ISBN;

    @Column(name = "Category")
    private String category;

    @Column(name = "publication_years")
    private int publicationYear;

    @Column(name = "Price")
    private float price;

    @Column(name = "Quantity")
    private int quantity;
    
    @Column(name="image")
    private String image;

    
	public Books(int bookId, String title, String iSBN, String category, int publicationYear, float price,
			int quantity,String image) {
		this.bookId = bookId;
		this.title = title;
		ISBN = iSBN;
		this.category = category;
		this.publicationYear = publicationYear;
		this.price = price;
		this.quantity = quantity;
	}

	public Books() {
	}

	public Books(int bookId, Authors author, Publication publication, String title, String iSBN, String category,
			int publicationYear, float price, int quantity) {
		this.bookId = bookId;
		this.author = author;
		this.publication = publication;
		this.title = title;
		ISBN = iSBN;
		this.category = category;
		this.publicationYear = publicationYear;
		this.price = price;
		this.quantity = quantity;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public Authors getAuthor() {
		return author;
	}

	public void setAuthor(Authors author) {
		this.author = author;
	}

	public Publication getPublication() {
		return publication;
	}

	public void setPublication(Publication publication) {
		this.publication = publication;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getISBN() {
		return ISBN;
	}

	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getPublicationYear() {
		return publicationYear;
	}

	public void setPublicationYear(int publicationYear) {
		this.publicationYear = publicationYear;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "Books [bookId=" + bookId + ", author=" + author + ", publication=" + publication + ", title=" + title
				+ ", ISBN=" + ISBN + ", category=" + category + ", publicationYear=" + publicationYear + ", price="
				+ price + ", quantity=" + quantity + ", image=" + image + "]";
	}

	
	
    
}
